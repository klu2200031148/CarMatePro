<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.sql.*" %>
<!DOCTYPE html>
<html>
<head>
    <title>Car Details - More Info</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .navbar {
            background-color: #4a90e2;
            color: #fff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
        }
        .logo {
            font-size: 35px;
            font-family: Arial;
        }
        .menu ul {
            display: flex;
            list-style-type: none;
        }
        .menu ul li {
            margin-left: 20px;
        }
        .menu ul li a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            transition: color 0.3s ease;
        }
        .menu ul li a:hover {
            color: #ff7200;
        }
        .car-info-container {
            background-color: #fff;
            padding: 20px;
            margin: 100px auto;
            width: 80%;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .car-info-container h2 {
            text-align: center;
            color: #333;
        }
        .car-image {
            text-align: center;
            margin-bottom: 20px;
        }
        .car-image img {
            max-width: 100%;
            height: auto;
            border-radius: 10px;
        }
        .specifications, .features {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        .specifications div, .features div {
            width: 48%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #fff;
        }
        .specifications h3, .features h3 {
            margin-top: 0;
        }
        .expert-review {
            background-color: #fff;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .expert-review h3 {
            margin-top: 0;
        }
        .navbar, .footer {
            position: relative;
            z-index: 1000;
        }
        .footer {
            background-color: #333;
            color: #f2f2f2;
            text-align: center;
            padding: 10px;
            width: 100%;
            position: fixed;
            bottom: 0;
        }
        .footer p {
            margin: 0;
            padding: 0;
            font-family: Arial, Helvetica, sans-serif;
            font-size: 14px;
        }
        .footer a {
            color: #4a90e2;
            text-decoration: none;
            transition: color 0.3s ease;
        }
        .footer a:hover {
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <div class="logo">CarMatePro</div>
        <div class="menu">
            <ul>
                <li><a href="adminpage.Html">HOME</a></li>
                <li><a href="CarList.jsp">BACK TO LIST</a></li>
            </ul>
        </div>
    </div>

    <div class="car-info-container">
        <% 
        String companyName = request.getParameter("companyname");
        String carName = request.getParameter("carname");
        String sql = "SELECT * FROM cars WHERE companyname = ? AND carname = ?";

        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/epproject", "root", "Kavyasri@142005");
             PreparedStatement pstmt = con.prepareStatement(sql)) {
            pstmt.setString(1, companyName);
            pstmt.setString(2, carName);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                String carImage = rs.getString("carimage");
                String specifications = rs.getString("specifications");
                String features = rs.getString("features");
                String expertReview = rs.getString("expertReview");
        %>
        <div class="car-image">
            <img src="images/<%=carImage%>" alt="<%=carName%>">
        </div>
        <h2><%=carName%></h2>
        <div class="specifications">
            <div>
                <h3>Specifications</h3>
                <p><%=specifications%></p>
            </div>
            <div>
                <h3>Features</h3>
                <p><%=features%></p>
            </div>
        </div>
        <div class="expert-review">
            <h3>Expert Review</h3>
            <p><%=expertReview%></p>
        </div>
        <% 
            } else {
                out.println("Car not found.");
            }
        } catch(Exception e) {
            out.println(e);
        } 
        %>
    </div>

    <div class="footer">
        <p>&copy; 2024 CarMatePro. All rights reserved. <a href="mailto:contact@carmatepro.com">Contact Us</a></p>
    </div>
</body>
</html>
